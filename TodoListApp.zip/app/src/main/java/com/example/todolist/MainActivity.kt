package com.example.todolist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TodoApp()
        }
    }
}

@Composable
fun TodoApp(todoViewModel: TodoViewModel = viewModel()) {
    var textState by remember { mutableStateOf(TextFieldValue()) }

    Column(modifier = Modifier.padding(16.dp)) {
        BasicTextField(
            value = textState,
            onValueChange = { textState = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        )
        Button(onClick = { todoViewModel.addTask(textState.text) }) {
            Text("Add Task")
        }
        TodoList(todoViewModel)
    }
}

@Composable
fun TodoList(todoViewModel: TodoViewModel) {
    Column(modifier = Modifier.padding(top = 16.dp)) {
        todoViewModel.tasks.forEach { task ->
            Text(text = "- $task", modifier = Modifier.padding(4.dp))
        }
    }
}

class TodoViewModel : ViewModel() {
    private val _tasks = mutableStateListOf<String>()
    val tasks: List<String> get() = _tasks

    fun addTask(task: String) {
        if (task.isNotBlank()) {
            _tasks.add(task)
        }
    }
}
